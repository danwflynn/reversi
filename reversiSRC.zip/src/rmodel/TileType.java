package rmodel;


public enum TileType {
  BLACK, WHITE, EMPTY
}
